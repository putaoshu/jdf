define(function(require,exports,module){
	function init(){
		 console.log("这是CMD规范的js写法");
	}

	exports.init = init;
})