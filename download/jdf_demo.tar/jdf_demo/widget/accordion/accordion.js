seajs.use('jdf/1.0.0/ui/accordion/1.0.0/accordion',function(accordion){
	$('#accordion').accordion({
		itemClass:'ui-accordion-item',
		mainClass:'ui-accordion-main',
		widthDefault:165,
		widthCurrent:410
	});
});