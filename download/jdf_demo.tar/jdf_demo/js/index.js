/**
* @index
*/
seajs.use(["jdf/1.0.0/unit/globalInit/1.0.0/globalInit"], function (globalInit){
	// todo
});